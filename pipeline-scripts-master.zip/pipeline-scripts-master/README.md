# pipeline-scripts
Scripts to enable and Disable GO Agents via REST, Enable and Disable App status from Eureka Registry via REST

